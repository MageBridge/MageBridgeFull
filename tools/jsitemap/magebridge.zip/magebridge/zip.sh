#!/bin/bash
zip -r9 com_jmap_magebridge.zip language/ magebridge.php magebridge.xml index.html
