<?php
/*
 * Joomla! 1.5 component Magento Bridge
 *
 * @author Yireo (info@yireo.com)
 * @package MageBridge
 * @copyright Copyright 2009
 * @license GNU Public License
 * @link http://www.yireo.com
 */

defined('_JEXEC') or die('Restricted Access');

/* 
 * xmap extension-class for MageBridge
 */
class xmap_com_magebridge {

    /*
     * Method called by Xmap with the parent Menu-Item and some (empty) parameters
     *
     * @access public
     * @param XmapHtml $xmap
     * @param object $parent
     * @param array $params
     * @return null
     */
    public function getTree( &$xmap, &$parent, &$params ) 
    {
        // Only build a subtree for the MageBridge Root Menu-Item
        if($parent->link != 'index.php?option=com_magebridge&view=root') {
            return;
        }

        // Build the arguments
        $arguments = array(
            'active' => 1,
        );

        if(isset($params['enable_products']) && $params['enable_products'] == 1) {
            $arguments['include_products'] = true;
        }

        // Build the bridge
        $results = xmap_com_magebridge::getAPIResult($arguments);
        $tree = $results[0];
        $root_category = $results[1];

        // Call the recursive function to build the categories underneath the root
        if(!empty($tree) && isset($tree['children']) && $root_category > 0) {
            xmap_com_magebridge::getCategoryTree($xmap, $tree['children'], $root_category, $params);
        }
    
        return null;
    }

    /*
     * Static method to get the right result from the API
     * 
     * @access public
     * @param XmapHtml $xmap
     * @param array $tree
     * @param int $root_category
     * @return null
     */
    public function getAPIResult($arguments)
    {
        // Include the MageBridge register
        $register = MageBridgeModelRegister::getInstance();
        $register->add('api', 'magebridge_category.tree', $arguments);

        // Include the MageBridge bridge
        $bridge = MageBridgeModelBridge::getInstance();
        $bridge->build();
        $root_category = (int)$bridge->getMageConfig('root_category');

        // Get the result
        $tree = $bridge->getAPI('magebridge_category.tree', $arguments);

        // Return the bundled result
        return array(
            0 => $tree,
            1 => $root_category,
        );
    }

    /*
     * Recursive method to build Xmap nodes that represent the Magento categories
     * 
     * @access public
     * @param XmapHtml $xmap
     * @param array $tree
     * @param int $root_category
     * @param JParameter $params
     * @return null
     */
    public function getCategoryTree( &$xmap, &$tree, $root_category = 0, $params = null)
    {
        // Only continue if there are still categories in this tree
        if(!empty($tree)) {
            foreach($tree as $category) {

                // Do not continue, if this is a Root Category for a different Website
                if($category['parent_id'] == 0 && $category['category_id'] != $root_category) {
                    continue;
                }

                // Index this category only if it's not the Root Category
                if($category['parent_id'] > 0 && $category['category_id'] != $root_category) {

                    $node = new stdclass;
                    $node->id = $category['category_id'];
                    $node->browserNav = null;
                    $node->uid = $category['category_id'];
                    $node->name = $category['name'];
                    $node->priority = (isset($params['category_priority'])) ? $params['category_priority'] : -1;
                    $node->changefreq = (isset($params['category_changefreq'])) ? $params['category_changefreq'] : -1 ;
                    $node->link = 'index.php?option=com_magebridge&amp;view=root&amp;request='.$category['url'];
                    $node->expandible = true;
                    $rs = $xmap->printNode($node);
        
                }

                // If there are any products, include them 
                if(isset($category['products']) && !empty($category['products'])) {
                    $xmap->changeLevel(1);
                    xmap_com_magebridge::getProductNodes($xmap, $category['products'], $params) ;
                    $xmap->changeLevel(-1);
                }

                // If there are any subcategories, include them recursively
                if(isset($category['children']) && !empty($category['children'])) {
                    $xmap->changeLevel(1);
                    xmap_com_magebridge::getCategoryTree( $xmap, $category['children'], $root_category, $params);
                    $xmap->changeLevel(-1);
                }
            }
        }

        return null;
    }

    /*
     * Method to build Xmap nodes that represent the Magento products
     * 
     * @access public
     * @param XmapHtml $xmap
     * @param array $products
     * @param JParameter $params
     * @return null
     */
    public function getProductNodes(&$xmap, &$products, $params = null)
    {
        if(!empty($products)) {
            foreach($products as $product) {
                $node = new stdclass;
                $node->id = $product['product_id'];
                $node->browserNav = null;
                $node->uid = $product['product_id'];
                $node->name = $product['name'];
                $node->priority = (isset($params['product_priority'])) ? $params['product_priority'] : -1;
                $node->changefreq = (isset($params['product_changefreq'])) ? $params['product_changefreq'] : -1;
                $node->link = 'index.php?option=com_magebridge&amp;view=root&amp;request='.$product['url_key'];
                $node->expandible = true;
                $rs = $xmap->printNode($node);
            }
        }
    }
}
