<?php
/**
 * Magento Bridge
 *
 * @author Yireo
 * @package Magento Bridge
 * @copyright Copyright 2011 Yireo.com
 * @license GNU/GPL
 * @link http://www.yireo.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

class ProductApplication extends Application 
{
}
