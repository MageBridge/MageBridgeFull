<?php
/**
 * Magento Bridge
 *
 * @author Yireo
 * @package Magento Bridge
 * @copyright Copyright 2011 Yireo.com
 * @license GNU/GPL
 * @link http://www.yireo.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once dirname(dirname(__FILE__)).DS.'magebridge.php';

class ElementBlock extends ElementMageBridge
{
    public function edit() 
    {
        $html = array();
        $html[] = '<div>';
        $html[] = $this->getInputHtml('Magento block type', 'block_type');
        $html[] = $this->getInputHtml('Magento PHTML-template', 'block_template');
        $html[] = '</div>';
        return implode("&nbsp;", $html);
    }

    public function render($params = array())
    {
        $product_id = $this->getProductId();
        $block_type = $this->_data->get('block_type');
        $block_template = $this->_data->get('block_template');

        if(empty($block_type)) return null;

        $template = (!empty($block_template)) ? ' template="'.$block_template.'"' : null;
        $product_id = (!empty($product_id)) ? ' product_id="'.(int)$product_id.'"' : null;
        $code = '{{block type="'.$block_type.'" '.$product_id.$template.'}}';

        return $code;
    }
}
