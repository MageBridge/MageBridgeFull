<?php
/**
 * Magento Bridge
 *
 * @author Yireo
 * @package Magento Bridge
 * @copyright Copyright 2011 Yireo.com
 * @license GNU/GPL
 * @link http://www.yireo.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

class ElementMageBridge extends Element
{
    public function edit() 
    {
        // Implemented in subclasses
    }

    public function getProductId() 
    {
        $params = $this->_item->getParams();
        if(is_object($params)) {
            return $params->get('config.product_id');
        }
    }

    public function hasValue($params = array())
    {
        if($this->getProductId() > 0) {
            return true;
        }
        return false;
    }

    public function getInputHtml($label, $name, $value = null, $attributes = null)
    {
        $size = (isset($attributes['size'])) ? $attributes['size'] : 40;
        return '<label><strong>'.JText::_($label).'</strong></label><br/>'
            . '<input type="text" name="elements['.$this->identifier.']['.$name.']" value="'.$this->_data->get($name, $value)
            .'" size="'.$size.'" maxlength="255" /><br/><br/>'
        ;
    }
}
