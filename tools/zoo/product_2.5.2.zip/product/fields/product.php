<?php
/*
 * Joomla! component MageBridge
 *
 * @author Yireo (info@yireo.com)
 * @package MageBridge
 * @copyright Copyright 2013
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// Check to ensure this file is included in Joomla!
defined('JPATH_BASE') or die();
    
$returnType = 'id';
$name = $control_name.'['.$name.']';

// Are the API widgets enabled?
if(MagebridgeModelConfig::load('api_widgets') == true) {

    // Load the javascript
    JHTML::script('media/com_magebridge/js/backend-elements.js');
    JHTML::_('behavior.modal', 'a.modal');

    $title = (int)$value;
    $link = 'index.php?option=com_magebridge&amp;view=element&amp;tmpl=component&amp;ajax=1&amp;type=product&amp;object='.$name.'&amp;return='.$returnType.'&amp;current='.$value;

    $html = '<div style="float: left;">';
    $html .= '<input type="text" id="'.$name.'" name="'.$name.'" value="'.$title.'" />';
    $html .= '</div>';
    $html .= '<div class="button2-left"><div class="blank">';
    $html .= '<a class="modal" title="'.JText::_('Select a Product').'"  href="'.$link.'" rel="{handler: \'iframe\', size: {x:800, y:450}}">'.JText::_('Select').'</a>';
    $html .= '</div></div>'."\n";

    echo $html;
} else {
    echo '<input type="text" name="'.$name.'" value="'.$value.'" />';
}
