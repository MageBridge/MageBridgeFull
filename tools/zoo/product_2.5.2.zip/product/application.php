<?php
/**
 * MageBridge ZOO App
 *
 * @author Yireo
 * @package MageBridge ZOO App
 * @copyright Copyright 2013 Yireo.com
 * @license GNU/GPL
 * @link http://www.yireo.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

class ProductApplication extends Application 
{
}
