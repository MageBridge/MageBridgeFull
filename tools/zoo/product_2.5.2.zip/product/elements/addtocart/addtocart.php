<?php
/**
 * MageBridge ZOO App
 *
 * @author Yireo
 * @package MageBridge
 * @copyright Copyright 2013 Yireo.com
 * @license GNU/GPL
 * @link http://www.yireo.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once dirname(dirname(__FILE__)).'/magebridge.php';

class ElementAddtocart extends ElementMageBridge
{
    public function edit() 
    {
        $html = array();
        $html[] = '<div>';
        $html[] = $this->getInputHtml('Quantity', 'quantity', 1, array('size' => 5));
        $html[] = $this->getInputHtml('Product Options', 'options');
        $html[] = $this->getInputHtml('Return URL', 'returnurl');
        $html[] = $this->getInputHtml('Label', 'label', 'Add to cart');
        $html[] = '</div>';
        return implode("&nbsp;", $html);
    }

    public function render($params = array())
    {
        $product_id = $this->getProductId();
        $quantity = $this->get('quantity', 1);
        $options = $this->get('options');
        $returnurl = $this->get('returnurl');
        $label = $this->get('label', 'Add to cart');

        $url = 'index.php?option=com_magebridge&view=root&request=checkout/cart/add?product='.$product_id;
        if($quantity > 0) $url .= '&qty='.$quantity;
        if(!empty($returnurl)) $url .= '&uenc='.strtr(base64_encode($returnurl), '+/=', '-_,');
        if(!empty($options)) $url .= '&'.$options;

        return '<button onclick="parent.location=\''.JRoute::_($url).'\'"><span><span>'.JText::_($label).'</span></span></button>';
    }
}
