<?php
/**
 * MageBridge ZOO App
 *
 * @author Yireo
 * @package MageBridge
 * @copyright Copyright 2013 Yireo.com
 * @license GNU/GPL
 * @link http://www.yireo.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once dirname(dirname(__FILE__)).'/magebridge.php';

class ElementBlock extends ElementMageBridge
{
    public function edit() 
    {
        $html = array();
        $html[] = '<div>';
        $html[] = $this->getInputHtml('Magento XML-name', 'block_name');
        $html[] = '</div>';
        return implode("&nbsp;", $html);
    }

    public function render($params = array())
    {
        $product_id = $this->getProductId();
        $block_name = $this->_data->get('block_name');

        if(empty($block_name)) return null;
        if(empty($product_id)) return null;

        $code = '{mbrequest url="catalog/product/view/id/'.$product_id.'"}';
        $code .= '{mbblock name="'.$block_name.'"}';

        return $code;
    }
}
