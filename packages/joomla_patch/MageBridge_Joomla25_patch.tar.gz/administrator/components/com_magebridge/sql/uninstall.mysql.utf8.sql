DROP TABLE IF EXISTS `#__magebridge_config`;
DROP TABLE IF EXISTS `#__magebridge_log`;
DROP TABLE IF EXISTS `#__magebridge_connectors`;
DROP TABLE IF EXISTS `#__magebridge_stores`;
DROP TABLE IF EXISTS `#__magebridge_urls`;
DROP TABLE IF EXISTS `#__magebridge_products`;
DROP TABLE IF EXISTS `#__magebridge_products_log`;
DROP TABLE IF EXISTS `#__magebridge_usergroups`;
