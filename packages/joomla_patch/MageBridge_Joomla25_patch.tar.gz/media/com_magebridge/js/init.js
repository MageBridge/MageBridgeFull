/**
 * Joomla! component MageBridge
 *
 * @author Yireo (info@yireo.com)
 * @package MageBridge
 * @copyright Copyright 2016
 * @link https://www.yireo.com
 */

// Initialize jQuery
$j = jQuery.noConflict();
