<?php
/**
 * Joomla! module MageBridge: Block
 *
 * @author Yireo (info@yireo.com)
 * @package MageBridge
 * @copyright Copyright 2015
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// No direct access
defined('_JEXEC') or die('Restricted access'); 
?>
<div id="magebridge-<?php echo $blockName; ?>" class="magebridge-module magebridge-cms-block">
	<?php echo $block; ?>
</div>
<div style="clear:both"></div>
