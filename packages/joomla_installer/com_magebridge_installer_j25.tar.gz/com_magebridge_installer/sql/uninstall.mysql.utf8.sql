DROP TABLE IF EXISTS `#__magebridge_config`;
