<?php
/**
 * MageBridge
 *
 * @author Yireo
 * @package MageBridge
 * @copyright Copyright 2011
 * @license Yireo EULA (www.yireo.com)
 * @link http://www.yireo.com
 */

/*
 * Class containing messages from sessions
 */
class Yireo_MageBridge_Model_Rewrite_Message_Collection extends Mage_Core_Model_Message_Collection
{
    /**
     * Adding new message to collection
     *
     * @param   Mage_Core_Model_Message_Abstract $message
     * @return  Mage_Core_Model_Message_Collection
     */
    public function addMessage(Mage_Core_Model_Message_Abstract $message)
    {
        // Only do this for MB, not Magento standalone
        if(Mage::getSingleton('magebridge/core')->getMetaData('enable_messages') == 1) {

            $response = Mage::app()->getFrontController()->getResponse();
            $text = base64_encode($message->getCode());
            switch($message->getType()) {
                case 'error':
                    $response->setHeader('X-MageBridge-Error', $text);
                    break;
                case 'warning':
                    $response->setHeader('X-MageBridge-Warning', $text);
                    break;
                case 'success':
                case 'notice':
                default:
                    $response->setHeader('X-MageBridge-Message', $text);
                    break;
            }

        }

        // Perform the parent action
        return parent::addMessage($message);
    }

    /**
     * Retrieve messages collection
     *
     * @return Mage_Core_Model_Message_Collection
     */
    public function getItems($type = null)
    {
        if(Mage::getSingleton('magebridge/core')->getMetaData('enable_messages') == 1) {
            if($type) return array();
        }
        return parent::getItems($type);
    }
}
