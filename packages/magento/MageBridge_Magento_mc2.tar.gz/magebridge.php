<?php
/**
 * Magento Bridge
 *
 * @author Yireo
 * @package Magento Bridge
 * @copyright Copyright 2011
 * @license Yireo EULA (www.yireo.com)
 * @link http://www.yireo.com
 */

// Basic PHP settings that can be overwritten
ini_set('zlib.output_compression', 0);
//ini_set('display_errors', 1);

// Use this for profiling
define('yireo_starttime', microtime(true));
if(function_exists('yireo_benchmark') == false) {
    function yireo_benchmark($title) {
        $yireo_totaltime = round(microtime(true) - yireo_starttime, 4);
        Mage::getSingleton('magebridge/debug')->profiler($title.': '.$yireo_totaltime.' seconds');
    }
}

// Initialize the bridge
require_once 'magebridge.class.php';
$magebridge = new MageBridge();

// Mask this request
$magebridge->premask();

// Support for Magento Compiler
$compilerConfig = 'includes/config.php';
if (file_exists($compilerConfig)) include $compilerConfig;

// Initialize the Magento application
require_once 'app/Mage.php';
try {
    $app_value = $magebridge->getMeta('app_value');
    $app_type = $magebridge->getMeta('app_type');
    $app_time = time();

    if($app_type == 'website' && $app_value != 'admin') {
        $app_value = (int)$app_value;
    }

    if($app_value == 'admin') {
        $app_type = null;
    }

    #Varien_Profiler::enable();
    #Mage::setIsDeveloperMode(true);

    if(!empty($app_value) && !empty($app_type)) {
        Mage::app($app_value, $app_type);
    } elseif(!empty($app_value)) {
        Mage::app($app_value);
    } else {
        Mage::app();
    }
    Mage::getSingleton('magebridge/debug')->notice("Mage::app($app_value,$app_type)", $app_time); // @todo: Is this working on all cases?
    yireo_benchmark('Mage::app()');

} catch(Exception $e) {
    Mage::getSingleton('magebridge/debug')->notice("Mage::app($app_value,$app_type) failed to start", $app_time);
    Mage::getSingleton('magebridge/debug')->notice("Fallback to Mage::app()", $app_time);
    Mage::app();
}

// Run the bridge
$magebridge->run();

// End
