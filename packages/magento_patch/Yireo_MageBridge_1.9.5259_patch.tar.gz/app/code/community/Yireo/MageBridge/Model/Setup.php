<?php
/**
 * MageBridge
 *
 * @author Yireo
 * @package MageBridge
 * @copyright Copyright 2014
 * @license Open Source License
 * @link http://www.yireo.com
 */

/*
 * MageBridge model for setting up the database
 */
class Yireo_MageBridge_Model_Setup extends Mage_Customer_Model_Entity_Setup
{
}
