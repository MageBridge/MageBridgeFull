<?php
namespace Yireo\Common\Exception;

class PageNotFound extends \Exception
{

}