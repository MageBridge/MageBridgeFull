<?php
namespace Yireo\Common\Exception;

class FileNotFound extends \Exception
{

}