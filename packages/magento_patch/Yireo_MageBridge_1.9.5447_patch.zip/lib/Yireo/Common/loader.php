<?php
// Include the loader
require_once __DIR__ . '/Yireo/Common/System/Autoloader.php';

// Add our own loader-function to SPL
\Yireo\Common\System\Autoloader::init();
