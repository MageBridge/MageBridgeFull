<?php
/**
 * MageBridge
 *
 * @author Yireo
 * @package MageBridge
 * @copyright Copyright 2015
 * @license Open Source License
 * @link http://www.yireo.com
 */

/*
 * MageBridge observer to various Magento events
 * @deprecated: Replaced with Yireo_MageBridge_Model_Observer
 */
class Yireo_MageBridge_Model_Listener extends Yireo_MageBridge_Model_Observer
{
}
