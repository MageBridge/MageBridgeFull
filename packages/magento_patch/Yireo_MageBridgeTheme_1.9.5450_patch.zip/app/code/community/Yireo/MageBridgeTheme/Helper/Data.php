<?php
/**
 * MageBridgeTheme
 *
 * @author Yireo
 * @package MageBridgeTheme
 * @copyright Copyright 2016
 * @license Open Source License
 * @link https://www.yireo.com
 */

class Yireo_MageBridgeTheme_Helper_Data extends Mage_Core_Helper_Abstract
{
}
