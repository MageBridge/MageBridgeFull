<?php 
/*
 * Joomla! component MageBridge
 *
 * @author Yireo (info@yireo.com)
 * @package MageBridge
 * @copyright Copyright 2013
 * @license GNU Public License
 * @link http://www.yireo.com
 */

defined('_JEXEC') or die('Restricted access');
?>
<tr>
    <td colspan="100">
        <?php echo $this->getImageTag('active.png'); ?> Published &nbsp; | &nbsp;
        <?php echo $this->getImageTag('inactive.png'); ?> Not Published &nbsp; | &nbsp;
        <?php echo $this->getImageTag('disabled.png'); ?> Not Available</td>
    </td>
</tr>
