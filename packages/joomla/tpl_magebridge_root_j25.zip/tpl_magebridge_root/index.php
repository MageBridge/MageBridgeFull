<?php
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<jdoc:include type="modules" name="root" />
