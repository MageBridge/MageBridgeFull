/**
 * Joomla! component MageBridge
 *
 * @author Yireo (info@yireo.com)
 * @package MageBridge
 * @copyright Copyright 2014
 * @link http://www.yireo.com
 */

// Initialize jQuery
$j = jQuery.noConflict();
