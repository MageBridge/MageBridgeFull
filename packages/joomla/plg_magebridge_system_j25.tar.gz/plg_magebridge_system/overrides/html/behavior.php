<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

abstract class JHtmlBehavior extends \Joomla\JHtmlBehavior
{
	public static function modal($selector = 'a.modal', $params = array())
	{
		return;
	}
}
