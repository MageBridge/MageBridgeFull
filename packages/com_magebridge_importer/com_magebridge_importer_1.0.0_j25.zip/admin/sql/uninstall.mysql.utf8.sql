DROP TABLE IF EXISTS `#__magebridge_importer_products`;
DROP TABLE IF EXISTS `#__magebridge_importer_product_values`;
